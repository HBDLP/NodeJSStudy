## Example 2: *Function arguments*

